/*
 * sinoscope_serial.h
 *
 *  Created on: 2011-10-19
 *      Author: francis
 */

#ifndef SINOSCOPE_SERIAL_H_
#define SINOSCOPE_SERIAL_H_

#include "sinoscope.h"

int sinoscope_image_serial(sinoscope_t *b_ptr);

#endif /* SINOSCOPE_SERIAL_H_ */
